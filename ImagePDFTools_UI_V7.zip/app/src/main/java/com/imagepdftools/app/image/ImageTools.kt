package com.imagepdftools.app.image

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream

object ImageTools {
    private fun bitmap(context: Context, uri: Uri): Bitmap? {
        val raw = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return null
        return try {
            val orientation = context.contentResolver.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }
                ?: ExifInterface.ORIENTATION_NORMAL
            val matrix = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.preScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.preScale(1f, -1f)
            }
            if (matrix.isIdentity) raw else Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, matrix, true).also { if (it !== raw) raw.recycle() }
        } catch (_: Exception) { raw }
    }

    private fun out(context: Context, name: String, ext: String): File =
        File(context.cacheDir, "${name}_${System.currentTimeMillis()}.$ext")

    fun compress(context: Context, uri: Uri, quality: Int): File? {
        val b = bitmap(context, uri) ?: return null
        val f = out(context, "compressed", "jpg")
        return try {
            FileOutputStream(f).use { b.compress(Bitmap.CompressFormat.JPEG, quality.coerceIn(10, 95), it) }
            f
        } catch (_: Exception) { f.delete(); null } finally { b.recycle() }
    }

    fun resizePercent(context: Context, uri: Uri, percent: Int): File? {
        val b = bitmap(context, uri) ?: return null
        val p = percent.coerceIn(10, 200) / 100f
        val w = (b.width * p).toInt().coerceAtLeast(1)
        val h = (b.height * p).toInt().coerceAtLeast(1)
        val r = Bitmap.createScaledBitmap(b, w, h, true)
        val f = out(context, "resized", "jpg")
        return try {
            FileOutputStream(f).use { r.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            f
        } catch (_: Exception) { f.delete(); null } finally {
            if (r !== b) r.recycle()
            b.recycle()
        }
    }

    fun resize(context: Context, uri: Uri, maxW: Int, maxH: Int): File? {
        val b = bitmap(context, uri) ?: return null
        val scale = minOf(maxW.toFloat() / b.width, maxH.toFloat() / b.height, 1f)
        val r = Bitmap.createScaledBitmap(b, (b.width * scale).toInt().coerceAtLeast(1), (b.height * scale).toInt().coerceAtLeast(1), true)
        val f = out(context, "resized", "jpg")
        return try {
            FileOutputStream(f).use { r.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            f
        } catch (_: Exception) { f.delete(); null } finally {
            if (r !== b) r.recycle()
            b.recycle()
        }
    }

    fun cropCenter(context: Context, uri: Uri, aspect: Float = 1f, percent: Int = 100): File? {
        val b = bitmap(context, uri) ?: return null
        val target = b.width.toFloat() / b.height.toFloat()
        val p = percent.coerceIn(10, 100) / 100f
        var w: Int
        var h: Int
        if (target > aspect) {
            h = (b.height * p).toInt().coerceAtLeast(1)
            w = (h * aspect).toInt().coerceAtLeast(1)
        } else {
            w = (b.width * p).toInt().coerceAtLeast(1)
            h = (w / aspect).toInt().coerceAtLeast(1)
        }
        w = w.coerceAtMost(b.width)
        h = h.coerceAtMost(b.height)
        val x = ((b.width - w) / 2).coerceAtLeast(0)
        val y = ((b.height - h) / 2).coerceAtLeast(0)
        val r = Bitmap.createBitmap(b, x, y, w, h)
        val f = out(context, "cropped", "jpg")
        return try {
            FileOutputStream(f).use { r.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            f
        } catch (_: Exception) { f.delete(); null } finally {
            if (r !== b) r.recycle()
            b.recycle()
        }
    }

    fun convert(context: Context, uri: Uri): File? {
        val b = bitmap(context, uri) ?: return null
        val mime = context.contentResolver.getType(uri)?.lowercase() ?: ""
        val name = uri.lastPathSegment?.lowercase() ?: ""
        val toPng = mime.contains("png") || name.endsWith(".png")
        val ext = if (toPng) "jpg" else "png"
        val format = if (toPng) Bitmap.CompressFormat.JPEG else Bitmap.CompressFormat.PNG
        val f = out(context, "converted", ext)
        return try {
            FileOutputStream(f).use { b.compress(format, if (toPng) 92 else 100, it) }
            f
        } catch (_: Exception) { f.delete(); null } finally { b.recycle() }
    }

    // Kept for compatibility with older callers.
    fun convertToPng(context: Context, uri: Uri): File? = convert(context, uri)
}
