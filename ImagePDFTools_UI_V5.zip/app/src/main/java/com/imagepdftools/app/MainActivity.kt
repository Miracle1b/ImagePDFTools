package com.imagepdftools.app

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.imagepdftools.app.ads.AdsManager
import com.imagepdftools.app.core.UsageManager
import com.imagepdftools.app.image.ImageTools
import com.imagepdftools.app.pdf.PdfTools
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

private data class Tool(val icon: String, val title: String, val subtitle: String, val accent: Color)

class MainActivity : ComponentActivity() {
    private lateinit var usage: UsageManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usage = UsageManager(this)
        AdsManager.init(this)
        setContent { App() }
    }

    private fun fileUri(file: File): Uri =
        FileProvider.getUriForFile(this, "$packageName.fileprovider", file)

    private fun share(files: List<File>) {
        if (files.isEmpty()) return
        val intent = if (files.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = contentResolver.getType(fileUri(files[0])) ?: "application/octet-stream"
                putExtra(Intent.EXTRA_STREAM, fileUri(files[0]))
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "image/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(files.map(::fileUri)))
            }
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(intent, "Share result"))
    }

    @Composable
    private fun App() {
        val tools = listOf(
            Tool("🗜️", "Compress Image", "Reduce file size", Color(0xFF2563EB)),
            Tool("📐", "Resize Image", "Change dimensions", Color(0xFF7C3AED)),
            Tool("✂️", "Crop Image", "Choose crop ratio", Color(0xFFDB2777)),
            Tool("📄", "Image → PDF", "Create PDF", Color(0xFFEA580C)),
            Tool("🖼️", "PDF → Image", "Render pages", Color(0xFF0891B2)),
            Tool("🔄", "JPG ↔ PNG", "Convert format", Color(0xFF059669)),
            Tool("📷", "Document Scanner", "Camera capture", Color(0xFFCA8A04)),
            Tool("📤", "Share Files", "Share last result", Color(0xFF475569))
        )

        var selected by remember { mutableStateOf<Tool?>(null) }
        var selectedUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
        var results by remember { mutableStateOf<List<File>>(emptyList()) }
        var message by remember { mutableStateOf("") }
        var quality by remember { mutableStateOf(87f) }
        var widthText by remember { mutableStateOf("1080") }
        var heightText by remember { mutableStateOf("1080") }
        var cropRatio by remember { mutableStateOf("1:1") }
        var showReward by remember { mutableStateOf(false) }
        var showAbout by remember { mutableStateOf(false) }
        var rewardTool by remember { mutableStateOf("") }

        fun goHome() {
            selected = null
            selectedUris = emptyList()
            message = ""
        }

        BackHandler(enabled = selected != null) { goHome() }

        val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
            if (u != null) {
                selectedUris = listOf(u)
                results = emptyList()
                message = "Image selected. Adjust settings, then tap Process."
            }
        }

        val multiPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { us ->
            if (us.isNotEmpty()) {
                selectedUris = us
                results = emptyList()
                message = "${us.size} image(s) selected. Tap Create PDF."
            }
        }

        val pdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
            if (u != null) {
                selectedUris = listOf(u)
                results = emptyList()
                message = "PDF selected. Tap Render pages."
            }
        }

        val cameraUri = remember { mutableStateOf<Uri?>(null) }
        val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            if (ok && cameraUri.value != null) {
                selectedUris = listOf(cameraUri.value!!)
                results = emptyList()
                message = "Photo captured. Tap Scan document."
            }
        }

        val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { target ->
            if (target != null && results.isNotEmpty()) {
                contentResolver.openOutputStream(target)?.use { out ->
                    results.first().inputStream().use { input -> input.copyTo(out) }
                }
                message = "Saved successfully"
            }
        }

        fun requestTool(tool: Tool) {
            if (tool.title == "Share Files") {
                if (results.isNotEmpty()) share(results) else message = "No result file to share yet."
                return
            }
            selected = tool
            selectedUris = emptyList()
            results = emptyList()
            message = ""
            if (tool.title == "Document Scanner") {
                val f = File(cacheDir, "scan_${System.currentTimeMillis()}.jpg")
                val u = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
                cameraUri.value = u
                camera.launch(u)
            }
        }

        fun processCurrent() {
            val tool = selected?.title ?: return
            if (tool == "Document Scanner" && selectedUris.isEmpty()) {
                message = "Take a photo first."
                return
            }
            if (selectedUris.isEmpty()) {
                message = "Choose a file first."
                return
            }
            if (!usage.canUse(tool)) {
                rewardTool = tool
                showReward = true
                return
            }

            val action = {
                val files = when (tool) {
                    "Compress Image" -> listOfNotNull(ImageTools.compress(this, selectedUris.first(), quality.toInt()))
                    "Resize Image" -> listOfNotNull(
                        ImageTools.resize(
                            this,
                            selectedUris.first(),
                            widthText.toIntOrNull()?.coerceIn(100, 8000) ?: 1080,
                            heightText.toIntOrNull()?.coerceIn(100, 8000) ?: 1080
                        )
                    )
                    "Crop Image" -> listOfNotNull(ImageTools.cropCenter(this, selectedUris.first(), cropRatio.toAspect()))
                    "JPG ↔ PNG" -> listOfNotNull(ImageTools.convertToPng(this, selectedUris.first()))
                    "Image → PDF" -> listOfNotNull(PdfTools.imagesToPdf(this, selectedUris))
                    "PDF → Image" -> PdfTools.pdfToImages(this, selectedUris.first())
                    "Document Scanner" -> listOfNotNull(ImageTools.compress(this, selectedUris.first(), 92))
                    else -> emptyList()
                }
                if (files.isNotEmpty()) {
                    usage.consume(tool)
                    results = files
                    message = "Done • ${files.size} file(s)"
                } else {
                    message = "Could not process the selected file."
                }
            }
            if (usage.shouldShowInterstitial()) AdsManager.showInterstitial(this, action) else action()
        }

        val scheme = lightColorScheme(
            primary = Color(0xFF4F46E5), onPrimary = Color.White,
            secondary = Color(0xFF0891B2), background = Color(0xFFF7F8FC),
            surface = Color.White, surfaceVariant = Color(0xFFEFF1F7),
            onSurface = Color(0xFF172033), onSurfaceVariant = Color(0xFF687087)
        )

        MaterialTheme(colorScheme = scheme) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                if (selected == null) {
                    HomeScreen(tools, results, message, { requestTool(it) }, { showAbout = true })
                } else {
                    ToolScreen(
                        tool = selected!!,
                        selectedUris = selectedUris,
                        results = results,
                        quality = quality,
                        onQuality = { quality = it },
                        widthText = widthText,
                        onWidth = { widthText = it },
                        heightText = heightText,
                        onHeight = { heightText = it },
                        cropRatio = cropRatio,
                        onCropRatio = { cropRatio = it },
                        message = message,
                        onBack = { goHome() },
                        onPickImage = { imagePicker.launch("image/*") },
                        onPickImages = { multiPicker.launch("image/*") },
                        onPickPdf = { pdfPicker.launch("application/pdf") },
                        onProcess = { processCurrent() },
                        onShare = { share(results) },
                        onSave = { if (results.isNotEmpty()) saveLauncher.launch(results.first().name) }
                    )
                }
            }
        }

        if (showReward) {
            AlertDialog(
                onDismissRequest = { showReward = false },
                title = { Text("Daily limit reached") },
                text = { Text("Watch a rewarded ad to unlock one more use.") },
                confirmButton = {
                    TextButton(onClick = {
                        AdsManager.showRewarded(this, {
                            usage.grantOne(rewardTool)
                            showReward = false
                            message = "One extra use unlocked. Tap Process again."
                        }, {
                            showReward = false
                            message = "Rewarded ad is unavailable. Try again later."
                        })
                    }) { Text("Watch Ad") }
                },
                dismissButton = { TextButton(onClick = { showReward = false }) { Text("Cancel") } }
            )
        }

        if (showAbout) {
            AlertDialog(
                onDismissRequest = { showAbout = false },
                title = { Text("About Image & PDF Tools") },
                text = { Text("Process images and PDFs locally on your device. No account is required. Ads help keep the app free.") },
                confirmButton = { TextButton(onClick = { showAbout = false }) { Text("OK") } }
            )
        }
    }

    @Composable
    private fun HomeScreen(
        tools: List<Tool>, results: List<File>, message: String,
        onTool: (Tool) -> Unit, onAbout: () -> Unit
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Image & PDF", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                    Text("TOOLS", fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp, color = MaterialTheme.colorScheme.primary)
                }
                TextButton(onClick = onAbout) { Text("About") }
            }
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(26.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF2563EB), Color(0xFF7C3AED), Color(0xFFDB2777))))
                    .padding(20.dp)
            ) {
                Text("Everything you need for images & PDFs", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Fast • Simple • Private on your device", color = Color.White.copy(alpha = .88f), fontSize = 13.sp)
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AssistChip(onClick = {}, label = { Text("8 tools", fontSize = 12.sp) })
                    AssistChip(onClick = {}, label = { Text("5 uses/day", fontSize = 12.sp) })
                }
            }
            Text("Quick tools", Modifier.padding(start = 18.dp, top = 18.dp, bottom = 10.dp), fontSize = 18.sp, fontWeight = FontWeight.Bold)
            LazyVerticalGrid(
                columns = GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 18.dp), modifier = Modifier.weight(1f)
            ) {
                items(tools) { t ->
                    Card(onClick = { onTool(t) }, modifier = Modifier.height(142.dp), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
                            Box(Modifier.size(46.dp).clip(RoundedCornerShape(15.dp)).background(t.accent.copy(alpha = .12f)), contentAlignment = Alignment.Center) { Text(t.icon, fontSize = 25.sp) }
                            Column {
                                Text(t.title, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Spacer(Modifier.height(2.dp))
                                Text(t.subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
            if (message.isNotEmpty()) Text(message, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.primary)
        }
    }

    @Composable
    private fun ToolScreen(
        tool: Tool, selectedUris: List<Uri>, results: List<File>, quality: Float, onQuality: (Float) -> Unit,
        widthText: String, onWidth: (String) -> Unit, heightText: String, onHeight: (String) -> Unit,
        cropRatio: String, onCropRatio: (String) -> Unit, message: String, onBack: () -> Unit,
        onPickImage: () -> Unit, onPickImages: () -> Unit, onPickPdf: () -> Unit, onProcess: () -> Unit,
        onShare: () -> Unit, onSave: () -> Unit
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("‹  Back") }
                Text(tool.title, Modifier.weight(1f), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                if (tool.title == "Compress Image") {
                    Text("Compression quality: ${quality.toInt()}%", fontWeight = FontWeight.SemiBold)
                    Slider(value = quality, onValueChange = onQuality, valueRange = 10f..95f)
                }
                if (tool.title == "Resize Image") {
                    Text("Resize dimensions", fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(widthText, onWidth, Modifier.weight(1f), label = { Text("Width") }, singleLine = true)
                        OutlinedTextField(heightText, onHeight, Modifier.weight(1f), label = { Text("Height") }, singleLine = true)
                    }
                    Spacer(Modifier.height(8.dp))
                }
                if (tool.title == "Crop Image") {
                    Text("Crop ratio", fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                        listOf("1:1", "4:3", "16:9").forEach { ratio ->
                            FilterChip(selected = cropRatio == ratio, onClick = { onCropRatio(ratio) }, label = { Text(ratio) })
                        }
                    }
                }

                if (tool.title == "Image → PDF") {
                    Button(onClick = onPickImages, Modifier.fillMaxWidth()) { Text("Choose images") }
                } else if (tool.title == "PDF → Image") {
                    Button(onClick = onPickPdf, Modifier.fillMaxWidth()) { Text("Choose PDF") }
                } else if (tool.title != "Document Scanner") {
                    Button(onClick = onPickImage, Modifier.fillMaxWidth()) { Text(if (selectedUris.isEmpty()) "Choose image" else "Choose another image") }
                }

                if (selectedUris.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    InputPreview(selectedUris.first(), tool.title == "PDF → Image")
                    if (selectedUris.size > 1) Text("${selectedUris.size} images selected", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = onProcess, Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                        Text(
                            when (tool.title) {
                                "Image → PDF" -> "Create PDF"
                                "PDF → Image" -> "Render pages"
                                "Document Scanner" -> "Scan document"
                                else -> "Process image"
                            }
                        )
                    }
                } else if (tool.title == "Document Scanner") {
                    Text("Take a photo with the camera to start scanning.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                if (results.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    ResultPreview(results.first())
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
                        Button(onClick = onShare, Modifier.weight(1f)) { Text("Share") }
                        OutlinedButton(onClick = onSave, Modifier.weight(1f)) { Text("Save") }
                    }
                }
                if (message.isNotEmpty()) Text(message, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 12.dp))
            }
        }
    }

    @Composable
    private fun InputPreview(uri: Uri, isPdf: Boolean) {
        if (isPdf) {
            Box(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) { Text("📄 PDF selected", fontSize = 20.sp) }
            return
        }
        val bitmap by produceState<Bitmap?>(initialValue = null, key1 = uri) {
            value = withContext(Dispatchers.IO) { contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } }
        }
        if (bitmap != null) Image(bitmap!!.asImageBitmap(), "Selected image", contentScale = ContentScale.Fit, modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp).clip(RoundedCornerShape(16.dp)))
        else Text("Image selected")
    }

    @Composable
    private fun ResultPreview(file: File) {
        val ext = file.extension.lowercase()
        if (ext == "jpg" || ext == "jpeg" || ext == "png" || ext == "webp") {
            val bitmap by produceState<Bitmap?>(initialValue = null, key1 = file.absolutePath) { value = withContext(Dispatchers.IO) { decodePreview(file) } }
            if (bitmap != null) Image(bitmap!!.asImageBitmap(), "Result preview", contentScale = ContentScale.Fit, modifier = Modifier.fillMaxWidth().heightIn(max = 320.dp).clip(RoundedCornerShape(16.dp)))
        } else {
            Box(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) { Text("📄 ${file.name}") }
        }
    }

    private fun decodePreview(file: File): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) sample *= 2
            BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (_: Exception) { null }
    }
}

private fun String.toAspect(): Float = when (this) {
    "4:3" -> 4f / 3f
    "16:9" -> 16f / 9f
    else -> 1f
}
