# Privacy Policy — Image & PDF Tools

Last updated: [DATE]

Image & PDF Tools is designed to process files locally on the user's device where supported.

## Files
Selected images and documents are processed locally unless a future feature explicitly says otherwise.

## Advertising
The production version may use Google Mobile Ads or another approved advertising provider. That provider may process advertising-related information under its own policies.

## Personal information
The app should not request personal information unless a feature specifically requires it.

## Permissions
The app may request only permissions necessary for camera or file-related features.

## Contact
[YOUR CONTACT EMAIL]

Before publishing, replace placeholders and ensure this policy matches the actual implementation and all third-party SDKs.
