# Privacy Policy — Image & PDF Tools

This app processes selected images and PDF files locally on the device for the conversion features described in the app.

The app may use Google Mobile Ads to display advertisements and support the free service. Google's advertising services may process data according to Google's applicable privacy documentation and the consent choices available in supported regions.

The app does not require an account for its core conversion features.

Before publishing, the developer must replace this document with a final legally reviewed privacy policy hosted at a public HTTPS URL and configure the app/AdMob consent settings for the jurisdictions and audience served.
