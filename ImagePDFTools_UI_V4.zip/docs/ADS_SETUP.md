# AdMob setup

The source currently uses Google's official test App ID and test Interstitial/Rewarded ad unit IDs.

Before Play Store release:
1. Create/register the Android app in AdMob.
2. Replace the APPLICATION_ID in AndroidManifest.xml.
3. Replace TEST_INTERSTITIAL and TEST_REWARDED in AdsManager.kt with your own ad unit IDs.
4. Complete Google's required consent/privacy setup for the regions and audience your app serves.
5. Never click your own ads or use fake traffic.

Google documentation: https://developers.google.com/admob/android/quick-start
