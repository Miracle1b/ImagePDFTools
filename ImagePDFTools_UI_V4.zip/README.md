# Image & PDF Tools 2.0

Android utility app source project (Kotlin + Jetpack Compose).

## Included
- Compress Image
- Resize Image
- Center Crop Image
- Image to PDF (single or multiple images)
- PDF to Image (all pages)
- JPG to PNG
- Document Scanner capture (camera photo workflow)
- Secure FileProvider Share
- Save result using Android document picker
- 5 free uses/day per tool
- Rewarded ad unlocks one extra use after the daily limit
- Interstitial ads at selected natural transitions
- Local processing for image/PDF conversion

## Ads
This project uses Google's official TEST App ID and TEST ad unit IDs. Replace them with your own AdMob IDs before release. Current Google Mobile Ads setup follows Google's Android documentation.

## Build
Open the project in Android Studio and let Gradle sync. Then Build > Build APK(s).

## Important
An AdMob account/app and your production ad IDs cannot be created by source code. The project is intentionally shipped with Google test IDs so development does not generate production traffic.
