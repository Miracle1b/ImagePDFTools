package com.imagepdftools.app.core

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class UsageManager(context: Context) {
    private val p = context.getSharedPreferences("usage", Context.MODE_PRIVATE)
    private val limit = 5
    private fun day() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
    private fun key(tool: String) = "${day()}_${tool}"
    fun remaining(tool: String) = (limit - p.getInt(key(tool), 0)).coerceAtLeast(0)
    fun canUse(tool: String) = remaining(tool) > 0
    fun consume(tool: String) { p.edit().putInt(key(tool), p.getInt(key(tool),0)+1).apply() }
    fun grantOne(tool: String) { p.edit().putInt(key(tool), (p.getInt(key(tool),0)-1).coerceAtLeast(0)).apply() }
    fun shouldShowInterstitial(): Boolean {
        val n = p.getInt("ops_${day()}", 0) + 1
        p.edit().putInt("ops_${day()}", n).apply()
        return n % 3 == 0
    }
}
