package com.imagepdftools.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.core.content.FileProvider
import com.imagepdftools.app.ads.AdsManager
import com.imagepdftools.app.core.UsageManager
import com.imagepdftools.app.image.ImageTools
import com.imagepdftools.app.pdf.PdfTools
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private data class Tool(
    val icon: String,
    val title: String,
    val subtitle: String,
    val accent: Color
)

class MainActivity : ComponentActivity() {
    private lateinit var usage: UsageManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usage = UsageManager(this)
        AdsManager.init(this)
        setContent { App() }
    }

    private fun uri(file: File): Uri =
        FileProvider.getUriForFile(this, "$packageName.fileprovider", file)

    private fun share(files: List<File>) {
        if (files.isEmpty()) return

        val intent = if (files.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = contentResolver.getType(uri(files[0])) ?: "application/octet-stream"
                putExtra(Intent.EXTRA_STREAM, uri(files[0]))
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "image/*"
                putParcelableArrayListExtra(
                    Intent.EXTRA_STREAM,
                    ArrayList(files.map(::uri))
                )
            }
        }

        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(intent, "Share result"))
    }

    @Composable
    private fun App() {
        val tools = listOf(
            Tool("🗜️", "Compress Image", "Reduce file size", Color(0xFF2563EB)),
            Tool("📐", "Resize Image", "Change dimensions", Color(0xFF7C3AED)),
            Tool("✂️", "Crop Image", "Center crop", Color(0xFFDB2777)),
            Tool("📄", "Image → PDF", "Create PDF", Color(0xFFEA580C)),
            Tool("🖼️", "PDF → Image", "Render pages", Color(0xFF0891B2)),
            Tool("🔄", "JPG ↔ PNG", "Convert format", Color(0xFF059669)),
            Tool("📷", "Document Scanner", "Camera capture", Color(0xFFCA8A04)),
            Tool("📤", "Share Files", "Share last result", Color(0xFF475569))
        )

        var selected by remember { mutableStateOf<Tool?>(null) }
        var message by remember { mutableStateOf("") }
        var results by remember { mutableStateOf<List<File>>(emptyList()) }
        var quality by remember { mutableStateOf(60f) }
        var showReward by remember { mutableStateOf(false) }
        var showAbout by remember { mutableStateOf(false) }
        var rewardTool by remember { mutableStateOf("") }

        val imagePicker = rememberLauncherForActivityResult(
            ActivityResultContracts.GetContent()
        ) { u ->
            if (u != null) {
                processImage(
                    selected?.title ?: "",
                    listOf(u),
                    quality,
                    { f ->
                        results = f
                        message = "Done • ${f.size} file(s)"
                    },
                    { message = it },
                    showAd = usage.shouldShowInterstitial()
                )
            }
        }

        val multiPicker = rememberLauncherForActivityResult(
            ActivityResultContracts.GetMultipleContents()
        ) { us ->
            if (us.isNotEmpty()) {
                processImage(
                    "Image → PDF",
                    us,
                    quality,
                    { f ->
                        results = f
                        message = "Done • ${f.size} file(s)"
                    },
                    { message = it },
                    showAd = usage.shouldShowInterstitial()
                )
            }
        }

        val pdfPicker = rememberLauncherForActivityResult(
            ActivityResultContracts.GetContent()
        ) { u ->
            if (u != null) {
                if (!usage.canUse("PDF → Image")) {
                    rewardTool = "PDF → Image"
                    showReward = true
                } else {
                    val run = {
                        val files = PdfTools.pdfToImages(this, u)
                        if (files.isNotEmpty()) {
                            usage.consume("PDF → Image")
                            results = files
                            message = "Done • ${files.size} page(s)"
                        } else {
                            message = "Could not render this PDF."
                        }
                    }

                    if (usage.shouldShowInterstitial()) {
                        AdsManager.showInterstitial(this, run)
                    } else {
                        run()
                    }
                }
            }
        }

        val cameraUri = remember { mutableStateOf<Uri?>(null) }
        val camera = rememberLauncherForActivityResult(
            ActivityResultContracts.TakePicture()
        ) { ok ->
            if (ok && cameraUri.value != null) {
                processImage(
                    "Document Scanner",
                    listOf(cameraUri.value!!),
                    quality,
                    { f ->
                        results = f
                        message = "Scan complete"
                    },
                    { message = it },
                    showAd = false
                )
            }
        }

        val saveLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.CreateDocument("application/octet-stream")
        ) { target ->
            if (target != null && results.isNotEmpty()) {
                contentResolver.openOutputStream(target)?.use { out ->
                    results.first().inputStream().use { input -> input.copyTo(out) }
                }
                message = "Saved successfully"
            }
        }

        fun pick(tool: Tool) {
            selected = tool
            val title = tool.title

            if (title == "Share Files") {
                share(results)
                return
            }

            if (!usage.canUse(title)) {
                rewardTool = title
                showReward = true
                return
            }

            when (title) {
                "Compress Image", "Resize Image", "Crop Image", "JPG ↔ PNG" ->
                    imagePicker.launch("image/*")
                "Image → PDF" -> multiPicker.launch("image/*")
                "PDF → Image" -> pdfPicker.launch("application/pdf")
                "Document Scanner" -> {
                    val f = File(cacheDir, "scan_${System.currentTimeMillis()}.jpg")
                    val u = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
                    cameraUri.value = u
                    camera.launch(u)
                }
            }
        }

        val scheme = lightColorScheme(
            primary = Color(0xFF4F46E5),
            onPrimary = Color.White,
            secondary = Color(0xFF0891B2),
            background = Color(0xFFF7F8FC),
            surface = Color.White,
            surfaceVariant = Color(0xFFEFF1F7),
            onSurface = Color(0xFF172033),
            onSurfaceVariant = Color(0xFF687087)
        )

        MaterialTheme(colorScheme = scheme) {
            Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                Column(modifier = Modifier.fillMaxSize()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 18.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                "Image & PDF",
                                fontSize = 23.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                "TOOLS",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 3.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        TextButton(onClick = { showAbout = true }) {
                            Text("About")
                        }
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .clip(RoundedCornerShape(26.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFF2563EB), Color(0xFF7C3AED), Color(0xFFDB2777))
                                )
                            )
                            .padding(20.dp)
                    ) {
                        Text(
                            "Everything you need for images & PDFs",
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Fast • Simple • Private on your device",
                            color = Color.White.copy(alpha = 0.88f),
                            fontSize = 13.sp
                        )
                        Spacer(Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AssistChip(
                                onClick = {},
                                label = { Text("8 tools", fontSize = 12.sp) },
                                colors = AssistChipDefaults.assistChipColors(
                                    containerColor = Color.White.copy(alpha = 0.18f),
                                    labelColor = Color.White
                                )
                            )
                            AssistChip(
                                onClick = {},
                                label = { Text("5 uses/day", fontSize = 12.sp) },
                                colors = AssistChipDefaults.assistChipColors(
                                    containerColor = Color.White.copy(alpha = 0.18f),
                                    labelColor = Color.White
                                )
                            )
                        }
                    }

                    Text(
                        "Quick tools",
                        modifier = Modifier.padding(start = 18.dp, top = 18.dp, bottom = 10.dp),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(tools) { t ->
                            Card(
                                onClick = { pick(t) },
                                modifier = Modifier.height(142.dp),
                                shape = RoundedCornerShape(22.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(14.dp),
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(46.dp)
                                            .clip(RoundedCornerShape(15.dp))
                                            .background(t.accent.copy(alpha = 0.12f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(t.icon, fontSize = 25.sp)
                                    }
                                    Column {
                                        Text(
                                            t.title,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(Modifier.height(2.dp))
                                        Text(
                                            t.subtitle,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (selected?.title == "Compress Image") {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(18.dp),
                            color = Color.White
                        ) {
                            Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                                Text("Compression quality: ${quality.toInt()}%", fontWeight = FontWeight.SemiBold)
                                Slider(
                                    value = quality,
                                    onValueChange = { quality = it },
                                    valueRange = 10f..95f
                                )
                            }
                        }
                    }

                    if (results.isNotEmpty()) {
                        val previewFile = results.first()
                        val isImage = previewFile.extension.lowercase() in setOf("jpg", "jpeg", "png", "webp")
                        val isPdf = previewFile.extension.lowercase() == "pdf"

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(Modifier.padding(12.dp)) {
                                Text(
                                    "Result preview",
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
                                )
                                if (isImage) {
                                    val preview by produceState<Bitmap?>(initialValue = null, key1 = previewFile.absolutePath) {
                                        value = withContext(Dispatchers.IO) { decodePreview(previewFile) }
                                    }
                                    if (preview != null) {
                                        Image(
                                            bitmap = preview!!.asImageBitmap(),
                                            contentDescription = "Processed image preview",
                                            contentScale = ContentScale.Fit,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .heightIn(min = 160.dp, max = 360.dp)
                                                .clip(RoundedCornerShape(14.dp))
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(160.dp)
                                                .clip(RoundedCornerShape(14.dp))
                                                .background(MaterialTheme.colorScheme.surfaceVariant),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text("Loading image preview…")
                                        }
                                    }
                                } else if (isPdf) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(160.dp)
                                            .clip(RoundedCornerShape(14.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("📄", fontSize = 52.sp)
                                            Text("PDF ready", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(160.dp)
                                            .clip(RoundedCornerShape(14.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("📁", fontSize = 46.sp)
                                            Text("${previewFile.name}", maxLines = 2, overflow = TextOverflow.Ellipsis)
                                        }
                                    }
                                }
                                if (results.size > 1) {
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        "${results.size} result files",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { share(results) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(16.dp)
                            ) { Text("Share result") }
                            OutlinedButton(
                                onClick = { saveLauncher.launch(results.first().name) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(16.dp)
                            ) { Text("Save") }
                        }
                    }

                    if (message.isNotEmpty()) {
                        Text(
                            message,
                            modifier = Modifier.padding(start = 18.dp, end = 18.dp, bottom = 10.dp),
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        if (showReward) {
            AlertDialog(
                onDismissRequest = { showReward = false },
                title = { Text("Daily limit reached") },
                text = { Text("Watch a rewarded ad to unlock one more use.") },
                confirmButton = {
                    TextButton(onClick = {
                        AdsManager.showRewarded(
                            this,
                            {
                                usage.grantOne(rewardTool)
                                showReward = false
                                message = "One extra use unlocked."
                            },
                            {
                                showReward = false
                                message = "Rewarded ad is unavailable. Try again later."
                            }
                        )
                    }) { Text("Watch Ad") }
                },
                dismissButton = {
                    TextButton(onClick = { showReward = false }) { Text("Cancel") }
                }
            )
        }

        if (showAbout) {
            AlertDialog(
                onDismissRequest = { showAbout = false },
                title = { Text("About Image & PDF Tools") },
                text = {
                    Text(
                        "Process images and PDFs locally on your device. " +
                            "No account is required. Ads help keep the app free."
                    )
                },
                confirmButton = {
                    TextButton(onClick = { showAbout = false }) { Text("OK") }
                }
            )
        }
    }

    private fun decodePreview(file: File): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            var sample = 1
            while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) {
                sample *= 2
            }
            val options = BitmapFactory.Options().apply { inSampleSize = sample }
            BitmapFactory.decodeFile(file.absolutePath, options)
        } catch (_: Exception) {
            null
        }
    }

    private fun processImage(
        title: String,
        uris: List<Uri>,
        quality: Float,
        done: (List<File>) -> Unit,
        fail: (String) -> Unit,
        showAd: Boolean
    ) {
        if (!usage.canUse(title)) {
            fail("Daily limit reached. Watch an ad to continue.")
            return
        }

        val action = {
            val files = when (title) {
                "Compress Image" -> listOfNotNull(ImageTools.compress(this, uris.first(), quality.toInt()))
                "Resize Image" -> listOfNotNull(ImageTools.resize(this, uris.first(), 1080, 1080))
                "Crop Image" -> listOfNotNull(ImageTools.cropCenter(this, uris.first()))
                "JPG ↔ PNG" -> listOfNotNull(ImageTools.convertToPng(this, uris.first()))
                "Image → PDF" -> listOfNotNull(PdfTools.imagesToPdf(this, uris))
                "Document Scanner" -> listOfNotNull(ImageTools.compress(this, uris.first(), 92))
                else -> emptyList()
            }

            if (files.isNotEmpty()) {
                usage.consume(title)
                done(files)
            } else {
                fail("Could not process the selected file.")
            }
        }

        if (showAd) {
            AdsManager.showInterstitial(this, action)
        } else {
            action()
        }
    }
}
