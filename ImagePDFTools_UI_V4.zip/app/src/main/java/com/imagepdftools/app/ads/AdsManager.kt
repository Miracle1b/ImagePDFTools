package com.imagepdftools.app.ads

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

object AdsManager {
    // Google official test ad unit IDs. Replace with your own before publishing.
    private const val TEST_INTERSTITIAL = "ca-app-pub-3940256099942544/1033173712"
    private const val TEST_REWARDED = "ca-app-pub-3940256099942544/5224354917"
    private var interstitial: InterstitialAd? = null
    private var rewarded: RewardedAd? = null

    fun init(context: Context) { MobileAds.initialize(context) { loadInterstitial(context); loadRewarded(context) } }

    private fun loadInterstitial(context: Context) {
        InterstitialAd.load(context, TEST_INTERSTITIAL, AdRequest.Builder().build(), object: InterstitialAdLoadCallback() {
            override fun onAdLoaded(ad: InterstitialAd) { interstitial = ad }
            override fun onAdFailedToLoad(error: LoadAdError) { interstitial = null }
        })
    }

    private fun loadRewarded(context: Context) {
        RewardedAd.load(context, TEST_REWARDED, AdRequest.Builder().build(), object: RewardedAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedAd) { rewarded = ad }
            override fun onAdFailedToLoad(error: LoadAdError) { rewarded = null }
        })
    }

    fun showInterstitial(activity: Activity, after: () -> Unit) {
        val ad = interstitial
        if (ad == null) { after(); loadInterstitial(activity); return }
        interstitial = null
        ad.fullScreenContentCallback = object: com.google.android.gms.ads.FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { after(); loadInterstitial(activity) }
            override fun onAdFailedToShowFullScreenContent(e: com.google.android.gms.ads.AdError) { after(); loadInterstitial(activity) }
        }
        ad.show(activity)
    }

    fun showRewarded(activity: Activity, onReward: () -> Unit, onUnavailable: () -> Unit) {
        val ad = rewarded
        if (ad == null) { onUnavailable(); loadRewarded(activity); return }
        rewarded = null
        var earned = false
        ad.fullScreenContentCallback = object: com.google.android.gms.ads.FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { if (!earned) { onUnavailable() }; loadRewarded(activity) }
            override fun onAdFailedToShowFullScreenContent(e: com.google.android.gms.ads.AdError) { onUnavailable(); loadRewarded(activity) }
        }
        ad.show(activity) { earned = true; onReward() }
    }
}
