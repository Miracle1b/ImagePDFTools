package com.imagepdftools.app.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.os.ParcelFileDescriptor.AutoCloseInputStream
import java.io.File
import java.io.FileOutputStream

object PdfTools {
    private fun out(context: Context, name: String, ext: String) = File(context.cacheDir, "${name}_${System.currentTimeMillis()}.$ext")

    fun imageToPdf(context: Context, uri: Uri): File? = imagesToPdf(context, listOf(uri))

    fun imagesToPdf(context: Context, uris: List<Uri>): File? {
        val out = out(context, "images", "pdf")
        val doc = android.graphics.pdf.PdfDocument()
        try {
            uris.forEachIndexed { index, uri ->
                val b = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return@forEachIndexed
                val maxW = 595f; val maxH = 842f
                val s = minOf(maxW/b.width, maxH/b.height, 1f)
                val w=(b.width*s).toInt().coerceAtLeast(1); val h=(b.height*s).toInt().coerceAtLeast(1)
                val page = doc.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(595,842,index+1).create())
                val left=(595-w)/2f; val top=(842-h)/2f
                page.canvas.drawBitmap(b, null, android.graphics.RectF(left,top,left+w,top+h), null)
                doc.finishPage(page); b.recycle()
            }
            FileOutputStream(out).use { doc.writeTo(it) }
            return out
        } catch (_: Exception) { out.delete(); return null } finally { doc.close() }
    }

    fun pdfToImages(context: Context, uri: Uri): List<File> {
        val result = mutableListOf<File>()
        val pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: return result
        PdfRenderer(pfd).use { renderer ->
            for (i in 0 until renderer.pageCount) {
                renderer.openPage(i).use { page ->
                    val scale = 2f
                    val b = Bitmap.createBitmap((page.width*scale).toInt(), (page.height*scale).toInt(), Bitmap.Config.ARGB_8888)
                    b.eraseColor(android.graphics.Color.WHITE)
                    page.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    val f=out(context,"page_${i+1}","png")
                    FileOutputStream(f).use { b.compress(Bitmap.CompressFormat.PNG,100,it) }
                    b.recycle(); result += f
                }
            }
        }
        pfd.close(); return result
    }
}
