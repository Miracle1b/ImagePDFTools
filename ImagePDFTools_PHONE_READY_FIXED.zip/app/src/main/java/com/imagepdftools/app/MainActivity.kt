package com.imagepdftools.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.imagepdftools.app.ads.AdsManager
import com.imagepdftools.app.core.UsageManager
import com.imagepdftools.app.image.ImageTools
import com.imagepdftools.app.pdf.PdfTools
import java.io.File

private data class Tool(val icon: String, val title: String, val subtitle: String)

class MainActivity : ComponentActivity() {
    private lateinit var usage: UsageManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usage = UsageManager(this)
        AdsManager.init(this)
        setContent { App() }
    }

    private fun uri(file: File): Uri =
        FileProvider.getUriForFile(this, "$packageName.fileprovider", file)

    private fun share(files: List<File>) {
        if (files.isEmpty()) return

        val intent = if (files.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = contentResolver.getType(uri(files[0])) ?: "application/octet-stream"
                putExtra(Intent.EXTRA_STREAM, uri(files[0]))
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "image/*"
                putParcelableArrayListExtra(
                    Intent.EXTRA_STREAM,
                    ArrayList(files.map(::uri))
                )
            }
        }

        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(intent, "Share result"))
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun App() {
        val tools = listOf(
            Tool("🗜️", "Compress Image", "Reduce file size"),
            Tool("📐", "Resize Image", "Change dimensions"),
            Tool("✂️", "Crop Image", "Center crop"),
            Tool("📄", "Image → PDF", "Create PDF"),
            Tool("🖼️", "PDF → Image", "Render PDF pages"),
            Tool("🔄", "JPG ↔ PNG", "Convert format"),
            Tool("📷", "Document Scanner", "Camera capture"),
            Tool("📤", "Share Files", "Share last result")
        )

        var selected by remember { mutableStateOf<Tool?>(null) }
        var message by remember { mutableStateOf("") }
        var results by remember { mutableStateOf<List<File>>(emptyList()) }
        var quality by remember { mutableStateOf(60f) }
        var showReward by remember { mutableStateOf(false) }
        var showAbout by remember { mutableStateOf(false) }
        var rewardTool by remember { mutableStateOf("") }

        val imagePicker = rememberLauncherForActivityResult(
            ActivityResultContracts.GetContent()
        ) { u ->
            if (u != null) {
                processImage(
                    selected?.title ?: "",
                    listOf(u),
                    quality,
                    { f ->
                        results = f
                        message = "Done • ${f.size} file(s)"
                    },
                    { message = it },
                    showAd = usage.shouldShowInterstitial()
                )
            }
        }

        val multiPicker = rememberLauncherForActivityResult(
            ActivityResultContracts.GetMultipleContents()
        ) { us ->
            if (us.isNotEmpty()) {
                processImage(
                    "Image → PDF",
                    us,
                    quality,
                    { f ->
                        results = f
                        message = "Done • ${f.size} file(s)"
                    },
                    { message = it },
                    showAd = usage.shouldShowInterstitial()
                )
            }
        }

        val pdfPicker = rememberLauncherForActivityResult(
            ActivityResultContracts.GetContent()
        ) { u ->
            if (u != null) {
                if (!usage.canUse("PDF → Image")) {
                    rewardTool = "PDF → Image"
                    showReward = true
                } else {
                    val run = {
                        val files = PdfTools.pdfToImages(this, u)
                        if (files.isNotEmpty()) {
                            usage.consume("PDF → Image")
                            results = files
                            message = "Done • ${files.size} page(s)"
                        } else {
                            message = "Could not render this PDF."
                        }
                    }

                    if (usage.shouldShowInterstitial()) {
                        AdsManager.showInterstitial(this, run)
                    } else {
                        run()
                    }
                }
            }
        }

        val cameraUri = remember { mutableStateOf<Uri?>(null) }

        val camera = rememberLauncherForActivityResult(
            ActivityResultContracts.TakePicture()
        ) { ok ->
            if (ok && cameraUri.value != null) {
                processImage(
                    "Document Scanner",
                    listOf(cameraUri.value!!),
                    quality,
                    { f ->
                        results = f
                        message = "Scan complete"
                    },
                    { message = it },
                    showAd = false
                )
            }
        }

        val saveLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.CreateDocument("application/octet-stream")
        ) { target ->
            if (target != null && results.isNotEmpty()) {
                contentResolver.openOutputStream(target)?.use { out ->
                    results.first().inputStream().use { input -> input.copyTo(out) }
                }
                message = "Saved successfully"
            }
        }

        fun pick(tool: Tool) {
            selected = tool
            val title = tool.title

            if (title == "Share Files") {
                share(results)
                return
            }

            if (!usage.canUse(title)) {
                rewardTool = title
                showReward = true
                return
            }

            when (title) {
                "Compress Image", "Resize Image", "Crop Image", "JPG ↔ PNG" ->
                    imagePicker.launch("image/*")

                "Image → PDF" ->
                    multiPicker.launch("image/*")

                "PDF → Image" ->
                    pdfPicker.launch("application/pdf")

                "Document Scanner" -> {
                    val f = File(cacheDir, "scan_${System.currentTimeMillis()}.jpg")
                    val u = FileProvider.getUriForFile(
                        this,
                        "$packageName.fileprovider",
                        f
                    )
                    cameraUri.value = u
                    camera.launch(u)
                }
            }
        }

        MaterialTheme {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Text("Image & PDF Tools") },
                        actions = {
                            TextButton(onClick = { showAbout = true }) {
                                Text("Info")
                            }
                        }
                    )
                }
            ) { pad ->
                Column(
                    Modifier
                        .fillMaxSize()
                        .padding(pad)
                        .padding(16.dp)
                ) {
                    Text("Free • Local processing • 5 uses/day per tool", fontSize = 13.sp)
                    Spacer(Modifier.height(12.dp))

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(tools) { t ->
                            Card(
                                onClick = { pick(t) },
                                modifier = Modifier.height(135.dp)
                            ) {
                                Column(
                                    Modifier
                                        .fillMaxSize()
                                        .padding(10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Text(t.icon, fontSize = 28.sp)
                                    Text(t.title)
                                    Text(t.subtitle, fontSize = 11.sp)
                                }
                            }
                        }
                    }

                    if (selected?.title == "Compress Image") {
                        Text("Compression quality: ${quality.toInt()}%")
                        Slider(
                            value = quality,
                            onValueChange = { quality = it },
                            valueRange = 10f..95f
                        )
                    }

                    if (results.isNotEmpty()) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(onClick = { share(results) }) {
                                Text("Share")
                            }
                            OutlinedButton(onClick = { saveLauncher.launch(results.first().name) }) {
                                Text("Save")
                            }
                        }
                    }

                    if (message.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text(message)
                    }
                }
            }
        }

        if (showReward) {
            AlertDialog(
                onDismissRequest = { showReward = false },
                title = { Text("Daily limit reached") },
                text = { Text("Watch a rewarded ad to unlock one more use.") },
                confirmButton = {
                    TextButton(
                        onClick = {
                            AdsManager.showRewarded(
                                this,
                                {
                                    usage.grantOne(rewardTool)
                                    showReward = false
                                    message = "One extra use unlocked."
                                },
                                {
                                    showReward = false
                                    message = "Rewarded ad is unavailable. Try again later."
                                }
                            )
                        }
                    ) {
                        Text("Watch Ad")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showReward = false }) {
                        Text("Cancel")
                    }
                }
            )
        }

        if (showAbout) {
            AlertDialog(
                onDismissRequest = { showAbout = false },
                title = { Text("About") },
                text = {
                    Text(
                        "Image & PDF Tools processes files locally on your device. " +
                            "No account is required. Ads are used to support the free app."
                    )
                },
                confirmButton = {
                    TextButton(onClick = { showAbout = false }) {
                        Text("OK")
                    }
                }
            )
        }
    }

    private fun processImage(
        title: String,
        uris: List<Uri>,
        quality: Float,
        done: (List<File>) -> Unit,
        fail: (String) -> Unit,
        showAd: Boolean
    ) {
        if (!usage.canUse(title)) {
            fail("Daily limit reached. Watch an ad to continue.")
            return
        }

        val action = {
            val files = when (title) {
                "Compress Image" ->
                    listOfNotNull(ImageTools.compress(this, uris.first(), quality.toInt()))

                "Resize Image" ->
                    listOfNotNull(ImageTools.resize(this, uris.first(), 1080, 1080))

                "Crop Image" ->
                    listOfNotNull(ImageTools.cropCenter(this, uris.first()))

                "JPG ↔ PNG" ->
                    listOfNotNull(ImageTools.convertToPng(this, uris.first()))

                "Image → PDF" ->
                    listOfNotNull(PdfTools.imagesToPdf(this, uris))

                "Document Scanner" ->
                    listOfNotNull(ImageTools.compress(this, uris.first(), 92))

                else -> emptyList()
            }

            if (files.isNotEmpty()) {
                usage.consume(title)
                done(files)
            } else {
                fail("Could not process the selected file.")
            }
        }

        if (showAd) {
            AdsManager.showInterstitial(this, action)
        } else {
            action()
        }
    }
}
