package com.imagepdftools.app.image

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

object ImageTools {
    private fun bitmap(context: Context, uri: Uri): Bitmap? = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }

    private fun out(context: Context, name: String, ext: String): File = File(context.cacheDir, "${name}_${System.currentTimeMillis()}.$ext")

    fun compress(context: Context, uri: Uri, quality: Int): File? {
        val b = bitmap(context, uri) ?: return null
        val f = out(context, "compressed", "jpg")
        FileOutputStream(f).use { b.compress(Bitmap.CompressFormat.JPEG, quality.coerceIn(10,95), it) }
        b.recycle(); return f
    }

    fun resizePercent(context: Context, uri: Uri, percent: Int): File? {
        val b = bitmap(context, uri) ?: return null
        val p = percent.coerceIn(10, 200) / 100f
        val w = (b.width * p).toInt().coerceAtLeast(1)
        val h = (b.height * p).toInt().coerceAtLeast(1)
        val r = Bitmap.createScaledBitmap(b, w, h, true)
        val f = out(context, "resized", "jpg")
        FileOutputStream(f).use { r.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        r.recycle(); b.recycle(); return f
    }

    fun resize(context: Context, uri: Uri, maxW: Int, maxH: Int): File? {
        val b = bitmap(context, uri) ?: return null
        val scale = minOf(maxW.toFloat()/b.width, maxH.toFloat()/b.height, 1f)
        val r = Bitmap.createScaledBitmap(b, (b.width*scale).toInt().coerceAtLeast(1), (b.height*scale).toInt().coerceAtLeast(1), true)
        val f = out(context, "resized", "jpg")
        FileOutputStream(f).use { r.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        if (r !== b) r.recycle(); b.recycle(); return f
    }

    fun cropCenter(context: Context, uri: Uri, aspect: Float = 1f, percent: Int = 100): File? {
        val b = bitmap(context, uri) ?: return null
        val target = b.width.toFloat()/b.height
        val p = percent.coerceIn(10, 100) / 100f
        val w: Int; val h: Int; val x: Int; val y: Int
        if (target > aspect) { h=(b.height*p).toInt(); w=(h*aspect).toInt(); x=(b.width-w)/2; y=(b.height-h)/2 }
        else { w=(b.width*p).toInt(); h=(w/aspect).toInt(); x=(b.width-w)/2; y=(b.height-h)/2 }
        val r = Bitmap.createBitmap(b, x.coerceAtLeast(0), y.coerceAtLeast(0), w.coerceAtLeast(1), h.coerceAtLeast(1))
        val f = out(context, "cropped", "jpg")
        FileOutputStream(f).use { r.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        r.recycle(); b.recycle(); return f
    }

    fun convertToPng(context: Context, uri: Uri): File? {
        val b = bitmap(context, uri) ?: return null
        val f = out(context, "converted", "png")
        FileOutputStream(f).use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
        b.recycle(); return f
    }
}
